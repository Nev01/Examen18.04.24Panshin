﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MagazinSamokatov
{
    /// <summary>
    /// Логика взаимодействия для Page1AddMagazin.xaml
    /// </summary>
    public partial class Page1AddMagazin : Page
    {
        private Magazin _coorentMagazin = new Magazin();

        public Page1AddMagazin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_coorentMagazin.Nazvanie_magazina))
                errors.AppendLine("Укажите название магазина!");
            if (string.IsNullOrWhiteSpace(_coorentMagazin.Adres_magazina))
                errors.AppendLine("Укажите адрес магазина!");
            if (string.IsNullOrWhiteSpace(_coorentMagazin.Telefon_magazina))
                errors.AppendLine("Укажите телефон магазина!");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_coorentMagazin.ID_magazina == 0)
                MagazinSamokatEntities.GetContext().Magazin.Add(_coorentMagazin);

            try 
            {
                MagazinSamokatEntities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранина!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
