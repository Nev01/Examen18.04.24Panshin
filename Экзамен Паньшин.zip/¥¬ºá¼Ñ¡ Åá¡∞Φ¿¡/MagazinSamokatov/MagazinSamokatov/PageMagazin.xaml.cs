﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MagazinSamokatov
{
    /// <summary>
    /// Логика взаимодействия для PageMagazin.xaml
    /// </summary>
    public partial class PageMagazin : Page
    {
        //private Magazin _coorentMagazin = new Magazin();
        public PageMagazin()
        {
            InitializeComponent();
            //DataContext= _coorentMagazin;
            TablMagazin.ItemsSource = MagazinSamokatEntities.GetContext().Magazin.ToList();
        }

        private void BntAddMagazin(object sender, RoutedEventArgs e)
        {
            Glavnai1.Navigate(new Page1AddMagazin());
        }
    }
}
